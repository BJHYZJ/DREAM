"""Offline integrity verification of retained compact comparison records."""
import hashlib
import json
from pathlib import Path
import zipfile


def main():
    root = Path(__file__).parent / "evidence" / "study"
    manifest = json.loads((root / "manifest.json").read_text())
    if manifest["attempt_archives"] != 60:
        raise ValueError("Incomplete attempt archive set")
    for name, expected in manifest["files"].items():
        path = root / name
        if path.is_symlink() or not path.resolve().is_relative_to(root.resolve()):
            raise ValueError("Unsafe evidence path")
        payload = path.read_bytes()
        if len(payload) != expected["bytes"] or hashlib.sha256(payload).hexdigest() != expected["sha256"]:
            raise ValueError(f"Evidence file changed: {name}")
        if expected["kind"] == "zip":
            with zipfile.ZipFile(path) as archive:
                if set(archive.namelist()) != set(expected["members"]):
                    raise ValueError("Archive member set changed")
                for member, row in expected["members"].items():
                    payload = archive.read(member)
                    if len(payload) != row["bytes"] or hashlib.sha256(payload).hexdigest() != row["sha256"]:
                        raise ValueError(f"Archived record changed: {member}")
    print(json.dumps({"compact_evidence_verified": True, "attempts_retained": 60,
                      "raw_sensor_video_audit_performed": False, "new_policy_execution": False}))


if __name__ == "__main__":
    main()
