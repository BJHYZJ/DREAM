from pathlib import Path
import os,sys,json,tempfile,shutil
root=Path.cwd();run=root/'.runtime/residential-long-search-memory07/cases/07_ProcTHOR-Train-1402_seed42_dynamic';source=run/'frozen_workspace/DREAM_code';record=run/run.name;out=root/'.runtime/long-search-video/grasp_repair';out.mkdir()
protocol=json.loads((run/'protocol.json').read_text());os.environ.update(CUDA_VISIBLE_DEVICES='',HF_HUB_OFFLINE='1',VK_ICD_FILENAMES='/usr/share/vulkan/icd.d/lvp_icd.x86_64.json',MS_ASSET_DIR=protocol['asset_root'],HF_HUB_CACHE=protocol['model_cache'])
sys.path[:0]=[str(source/'experiments'),str(source/'src')]
import cv2,numpy as np,imageio.v2 as imageio
import replay_instruction_actions as replay
from instruction_replay_video import spectator_geometry
from mani_skill.utils import sapien_utils
cv2.setNumThreads(2)
rows=json.loads((record/'evaluator_trajectory.json').read_text());last=max(r['step'] for r in rows if r['task_stage']=='grasp');actions=json.loads((record/'actions.json').read_text())
prefix=out/'prefix';prefix.mkdir()
for p in record.iterdir():
 if p.suffix in ('.json','.jsonl') or p.name=='evaluator_room_map.npz':
  if p.name not in ('actions.json','evaluator_trajectory.json','evaluator_trajectory.jsonl'): (prefix/p.name).symlink_to(p)
(prefix/'actions.json').write_text(json.dumps(actions[:last]));(prefix/'evaluator_trajectory.json').write_text(json.dumps(rows[:last]))
local=Path(tempfile.mkdtemp(prefix='dream-grasp-video-'))/'grasp.mp4';writer=imageio.get_writer(local,fps=5,codec='libx264',quality=None,macro_block_size=2,ffmpeg_log_level='error',output_params=['-crf','25','-preset','veryfast','-threads','2','-pix_fmt','yuv420p','-movflags','+faststart']);frames=[]
original=replay.SimulatorIO
class VideoIO(original):
 def __init__(self,env):
  super().__init__(env);self.n=0;step=env.step
  def wrapped(action):
   value=step(action);self.n+=1;r=rows[self.n-1]
   if r['task_stage']=='grasp' and self.n%4==0:
    pose=self.pose();tcp=replay.array(self.robot.tcp_pose.p)[0];eye,look,fovy=spectator_geometry(pose,tcp,self.overview_heading,r['phase'],'tool-front-placement');camera=self.base._human_render_cameras['render_camera'].camera;camera.set_fovy(fovy);camera.set_local_pose(sapien_utils.look_at(eye,look).sp);rgb=replay.array(self.base.render_rgb_array('render_camera'))[0].astype(np.uint8)
    canvas=np.full((600,960,3),248,np.uint8);canvas[48:588]=rgb
    cv2.putText(canvas,f'Case 07 | {self.n/20:.1f} s robot time | 1x playback',(14,20),cv2.FONT_HERSHEY_SIMPLEX,.56,(30,30,30),1,cv2.LINE_AA);cv2.putText(canvas,r['phase'],(14,41),cv2.FONT_HERSHEY_SIMPLEX,.53,(30,30,30),1,cv2.LINE_AA);writer.append_data(canvas);frames.append(dict(sim_step=self.n,sim_time_s=self.n/20,phase=r['phase']))
   return value
  env.step=wrapped
replay.SimulatorIO=VideoIO;sys.argv=['replay','--source-run',str(prefix),'--output',str(out/'physical')]
try:replay.main()
finally:writer.close()
audit=json.loads((out/'physical/audit.json').read_text());assert audit['physical_reexecution_passed'] and max(audit['maximum_error'].values())==0
c=cv2.VideoCapture(str(local));n=0
while c.read()[0]:n+=1
c.release();assert n==len(frames)==287
shutil.copyfile(local,root/'.runtime/long-search-video/render/grasp.mp4');(root/'.runtime/long-search-video/render/grasp_frames.json').write_text(json.dumps(frames)+'\n');shutil.rmtree(local.parent)
print('REPAIRED',n,'frames; prefix replay exact',flush=True)
