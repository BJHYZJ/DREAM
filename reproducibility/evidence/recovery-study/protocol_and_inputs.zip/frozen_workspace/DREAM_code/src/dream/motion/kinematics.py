# Copyright (c) Meta Platforms, Inc. and affiliates.
#
# This source code is licensed under the MIT license found in the
# LICENSE file in the root directory of this source tree.
import math
import os
import numpy as np
import pinocchio
import cv2

from typing import List, Optional, Tuple
from pathlib import Path
from scipy.spatial.transform import Rotation
from dream.core.interfaces import ContinuousFullBodyAction
from dream.motion.base import IKSolverBase

from dream.motion.pinocchio_ik_solver import PinocchioIKSolver, PositionIKOptimizer
from dream.motion.robot import Footprint
from scipy.spatial.transform import Rotation as R

from transforms3d.quaternions import mat2quat
from transforms3d.euler import quat2euler
from dream.motion import constants

def quat2rpy(quat):
    # Convert to numpy array
    if type(quat) is list:
        quat = np.array(quat)
    # Convert to rpy
    rpy = np.array(quat2euler(quat, axes="sxyz")) / np.pi * 180
    return rpy

class RangerxARMKinematics:
    """Define motion planning structure for the robot. Exposes kinematics."""
    
    # Constants
    GRIPPER_OPEN = 830
    GRIPPER_CLOSED = 0
    
    # IK solver parameters (similar to PinocchioIKSolver)
    IK_EPS = 1e-4
    IK_MAX_ITER = 200
    IK_STEP_SIZE = 0.1
    IK_DAMPING = 1e-6
    # JOINT5_TILI_RANGE = [deg for deg in range(55, 145, 1)]
    # Fixed transform from end-effector frame (link_eef) to camera frame (camera_link)
    # Units: meters. Provided by user calibration.  # ros2 run tf2_ros tf2_echo link_eef camera_color_optical_frame
    # CAMERA_IN_EE = np.array([
    #     [-0.002, -0.868,  0.496,  0.100],
    #     [1.000, -0.005, -0.004, -0.032],
    #     [0.006,  0.496,  0.868, -0.147],
    #     [0.000,  0.000,  0.000,  1.000],
    # ], dtype=np.float32)

    # TILT_RANGE = [
    #     deg
    #     for deg in range(
    #         constants.SAFE_CAMERA_TILT_MIN_DEG,
    #         constants.SAFE_CAMERA_TILT_MAX_DEG + 1,
    #         1,
    #     )
    # ]
    # PAN_RANGE = [deg for deg in range(-45, 45, 1)]

    def __init__(
        self,
        urdf_path: Optional[str] = None,
        verbose: bool = False,
        camera_tilt_min_deg: int = 75,
        camera_tilt_max_deg: int = 135,
        camera_pan_min_deg: int = -45,
        camera_pan_max_deg: int = 45,
        camera_angle_step_deg: int = 1,
    ):
        """Initialize with Pinocchio for local IK computation.
        
        Args:
            urdf_path: Path to URDF file. If None, uses default xarm6_kinematics.urdf
            verbose: Whether to print detailed initialization info
        """
        camera_angle_step_deg = max(1, int(camera_angle_step_deg))
        self.camera_tilt_min_deg = int(camera_tilt_min_deg)
        self.camera_tilt_max_deg = int(camera_tilt_max_deg)
        self.camera_pan_min_deg = int(camera_pan_min_deg)
        self.camera_pan_max_deg = int(camera_pan_max_deg)
        self.camera_angle_step_deg = camera_angle_step_deg
        self.TILT_RANGE = list(
            range(
                self.camera_tilt_min_deg,
                self.camera_tilt_max_deg + 1,
                self.camera_angle_step_deg,
            )
        )
        self.PAN_RANGE = list(
            range(
                self.camera_pan_min_deg,
                self.camera_pan_max_deg + 1,
                self.camera_angle_step_deg,
            )
        )

        if urdf_path is None:
            urdf_path = str(
                Path(__file__).resolve().parents[2]  # .../DREAM/src
                / "dream_ros2_bridge" / "urdf" / "xarm6_kinematics.urdf"
            )
        
        self.model = pinocchio.buildModelFromUrdf(urdf_path)
        self.data = self.model.createData()
        self.ee_frame_name = "link_eef"
        self.ee_frame_id = self.model.getFrameId(self.ee_frame_name)
        self.verbose = verbose
        
        if verbose:
            print(f"[RangerxARM] Loaded URDF: {urdf_path}")
            print(f"[RangerxARM] Number of DOF: {self.model.nq}")
            print(f"[RangerxARM] End effector frame: {self.ee_frame_name}")
            print(f"[RangerxARM] Joint limits:")
            for i in range(min(6, self.model.nq)):
                lower = self.model.lowerPositionLimit[i]
                upper = self.model.upperPositionLimit[i]
                print(f"  Joint{i+1}: [{lower:.3f}, {upper:.3f}] rad = [{np.degrees(lower):.1f}°, {np.degrees(upper):.1f}°]")

    def get_footprint(self) -> Footprint:
        """Return footprint for the robot. This is expected to be a mask."""
        return Footprint(width=0.50, length=0.74, width_offset=0.0, length_offset=0.0)
    
    def check_angle_valid(self, joint_angles: np.ndarray):
        # avoid arm collison to back
        if (-15.0 <= joint_angles[0] <= 15.0) and (joint_angles[1] < -55.0):
            return False
        return True

    def manip_ik(
        self,
        target_pose: np.ndarray,
        q_init: Optional[np.ndarray] = None,
        is_radians: bool = True,
        return_degrees: bool = True,
        max_iterations: Optional[int] = None,
        verbose: bool = False
    ) -> Tuple[bool, Optional[np.ndarray], dict]:
        """Compute IK using Pinocchio iterative solver.
        
        Args:
            target_pose: 4x4 transformation matrix (position in meters)
            q_init: Initial joint angles [6] in radians. If None, uses a known good configuration.
            return_degrees: If True, return joint angles in degrees; otherwise radians
            max_iterations: Maximum IK iterations. If None, uses self.IK_MAX_ITER
            verbose: Print convergence info
        
        Returns:
            success: Whether IK converged
            joint_angles: Solution in degrees (if return_degrees=True) or radians [6]
            debug_info: Dict with 'iterations', 'final_error', 'final_error_norm'
        """
        if max_iterations is None:
            max_iterations = self.IK_MAX_ITER
        
        # Initialize joint configuration
        if q_init is None:
            q = np.deg2rad(constants.look_down)
        else:
            if not is_radians:
                q = np.deg2rad(q_init, dtype=float)
            else:
                q = np.asarray(q_init, dtype=float)
        
        # Ensure q has correct size for Pinocchio model
        if len(q) != self.model.nq:
            q = np.concatenate([q, np.zeros(self.model.nq - 6)])
        
        # Convert target pose to SE3
        target = pinocchio.SE3(target_pose[:3, :3], target_pose[:3, 3])
        
        # Iterative IK solver
        for iteration in range(max_iterations):
            pinocchio.forwardKinematics(self.model, self.data, q)
            pinocchio.updateFramePlacements(self.model, self.data)
            
            # Compute error in SE3 space
            error = pinocchio.log(self.data.oMf[self.ee_frame_id].inverse() * target).vector
            error_norm = np.linalg.norm(error)
            
            if verbose and iteration % 20 == 0:
                print(f"[IK] iter={iteration}, error_norm={error_norm:.6f}")
            # Check convergence
            if error_norm < self.IK_EPS and self.check_angle_valid(np.rad2deg(q[:6])):
                joint_angles = q[:6]
                if return_degrees:
                    joint_angles = np.rad2deg(joint_angles)
                
                debug_info = {
                    'iterations': iteration,
                    'final_error': error,
                    'final_error_norm': error_norm
                }
                return True, joint_angles, debug_info
            
            # Compute Jacobian and update step
            J = pinocchio.computeFrameJacobian(
                self.model, self.data, q, self.ee_frame_id, pinocchio.ReferenceFrame.LOCAL
            )
            dq = np.linalg.lstsq(J + self.IK_DAMPING * np.eye(6), error, rcond=None)[0]
            
            # Limit step size for stability
            step_norm = np.linalg.norm(dq)
            if step_norm > self.IK_STEP_SIZE:
                dq = dq * self.IK_STEP_SIZE / step_norm
            
            # Update configuration
            q = pinocchio.integrate(self.model, q, dq)

            # Wrap wrist roll (joint 6) to [-pi, pi] to avoid unnecessary 360 deg turns
            if self.model.nq >= 6:
                q[5] = ((q[5] + np.pi) % (2 * np.pi)) - np.pi
            
            # Enforce joint limits
            for i in range(min(6, self.model.nq)):
                q[i] = np.clip(q[i], self.model.lowerPositionLimit[i], self.model.upperPositionLimit[i])
        
        # Failed to converge
        debug_info = {
            'iterations': max_iterations,
            'final_error': error,
            'final_error_norm': error_norm
        }
        joint_angles = q[:6]
        if return_degrees:
            joint_angles = np.rad2deg(joint_angles)

        return False, joint_angles, debug_info
    
    def manip_fk(
        self,
        joint_angles: np.ndarray,
        return_mm: bool = False,
        return_pose: bool = True
    ) -> Tuple[np.ndarray, np.ndarray]:
        """Compute forward kinematics.
        
        Args:
            joint_angles: Joint angles [6] in radians
            return_mm: If True, return position in mm; otherwise meters
        
        Returns:
            position: End effector position [x, y, z]
            rotation: End effector rotation matrix [3x3]
        """
        # Ensure q has correct size for Pinocchio model
        if len(joint_angles) != self.model.nq:
            q = np.concatenate([joint_angles, np.zeros(self.model.nq - 6)])
        else:
            q = joint_angles
        
        pinocchio.forwardKinematics(self.model, self.data, q)
        pinocchio.updateFramePlacements(self.model, self.data)
        
        pose = self.data.oMf[self.ee_frame_id]
        position = pose.translation.copy()
        
        if return_mm:
            position *= 1000
        
        if return_pose:
            arm_pose = np.eye(4)
            arm_pose[:3, :3] = pose.rotation.copy()
            arm_pose[:3, 3] = position.copy()
            return arm_pose
        else:
            return position, pose.rotation.copy()
    
    @staticmethod
    def pose_from_xyzrpy(
        x: float, y: float, z: float,
        roll: float, pitch: float, yaw: float,
        degrees: bool = True,
        input_mm: bool = False
    ) -> np.ndarray:
        """Construct 4x4 transformation matrix from position and orientation.
        
        Args:
            x, y, z: Position
            roll, pitch, yaw: Orientation (ZYX Euler angles)
            degrees: If True, angles are in degrees; otherwise radians
            input_mm: If True, position is in mm; otherwise meters
        
        Returns:
            4x4 transformation matrix
        """
        pose = np.eye(4)
        
        # Position (convert mm to m if needed)
        if input_mm:
            pose[:3, 3] = [x / 1000, y / 1000, z / 1000]
        else:
            pose[:3, 3] = [x, y, z]
        
        # Rotation (ZYX convention: yaw-pitch-roll)
        pose[:3, :3] = R.from_euler('ZYX', [yaw, pitch, roll], degrees=degrees).as_matrix()
        
        return pose

    @staticmethod
    def xyzrpy_from_pose(
        pose: np.ndarray,
        degrees: bool = True,
        output_mm: bool = True
    ) -> Tuple[float, float, float, float, float, float]:
        """Extract position and ZYX-orientation (roll, pitch, yaw) from 4x4 pose.

        Uses the same convention as pose_from_xyzrpy: rotation = R.from_euler('ZYX', [yaw, pitch, roll]).
        """
        if pose.shape != (4, 4):
            raise ValueError(f"pose must be 4x4, got {pose.shape}")

        x, y, z = pose[:3, 3].astype(float)
        if output_mm:
            x, y, z = x * 1000.0, y * 1000.0, z * 1000.0

        # as_euler('ZYX') returns [yaw, pitch, roll]
        yaw, pitch, roll = R.from_matrix(pose[:3, :3]).as_euler('ZYX', degrees=degrees)
        return float(x), float(y), float(z), float(roll), float(pitch), float(yaw)


    def cal_tilt_err(
        self, 
        camera_in_arm_base_pose: np.ndarray, 
        target_in_arm_base: np.ndarray
    ) -> float:
        # Compute signed tilt error using camera_link axes: forward=+X, up=+Z.
        R_cam_in_arm_base_cur = camera_in_arm_base_pose[:3, :3]
        p_cam_in_arm_base_cur = camera_in_arm_base_pose[:3, 3]
        distance_arm_base_cur = target_in_arm_base - p_cam_in_arm_base_cur
        dist_cur = float(np.linalg.norm(distance_arm_base_cur))

        dir_cam_z = distance_arm_base_cur / dist_cur
        dir_cam_cur = R_cam_in_arm_base_cur.T @ (dir_cam_z)
        tilt_err = abs(np.arctan2(dir_cam_cur[1], dir_cam_cur[2]))
        return tilt_err


    def check_tilt_err(self, tilt: float) -> bool:
        if tilt < np.deg2rad(0.5):
            return True
        return False

    def _angle_cam_axis_to_target(
        self,
        camera_in_base_pose: np.ndarray,
        target_in_base: np.ndarray,
        axis_idx: int = 2,
        axis_sign: float = 1.0,
    ) -> float:
        """Return the angle (radians) between a camera axis and the direction to target.

        - camera_in_base_pose: 4x4, meters
        - target_in_base: 3, meters
        - axis_idx: camera axis index (0:X, 1:Y, 2:Z). Default 2 for Z-axis
        - axis_sign: +1 if the axis points forward, -1 to flip
        """
        Rm = camera_in_base_pose[:3, :3]
        pc = camera_in_base_pose[:3, 3]
        d = target_in_base - pc
        nd = float(np.linalg.norm(d))
        if nd < 1e-9:
            return float('inf')
        dir_to_tgt = d / nd
        cam_axis = axis_sign * Rm[:, axis_idx]
        cos_th = float(np.clip(np.dot(cam_axis, dir_to_tgt), -1.0, 1.0))
        return float(np.arccos(cos_th))


    def cal_u_err(self, target_in_camera: np.ndarray, camera_K: np.ndarray) -> float:
        """Return the horizontal error in pixels between the target and the camera center.

        - target_in_camera: 3, meters
        - camera_K: 3x3, camera intrinsics matrix
        """
        cx = camera_K[0, 2]
        u, _ = self.project_point_to_pixel(target_in_camera, camera_K)
        u_err = abs(u - cx)
        return u_err

    def cal_v_err(self, target_in_camera: np.ndarray, camera_K: np.ndarray) -> float:
        """Return the vertical error in pixels between the target and the camera center.

        - target_in_camera: 3, meters
        - camera_K: 3x3, camera intrinsics matrix
        """
        cy = camera_K[1, 2]
        _, v = self.project_point_to_pixel(target_in_camera, camera_K)
        v_err = abs(v - cy)
        return v_err

    def project_point_to_pixel(self, points, intrinsic):
        assert points.shape == (1,) or points.shape == (3,), "points must be 1x3 or 3x1"
        if points.shape != (3,):
            points = points.reshape(1, 1, 3)
        u, v = cv2.projectPoints(
            points, 
            np.zeros(3), 
            np.zeros(3), 
            intrinsic, 
            np.zeros(5)
        )[0][0, 0, :]
        return u, v


    def compute_look_at_target_tilt(
        self,
        arm_angles_deg: np.ndarray,
        target_in_camera: np.ndarray,
        camera_in_arm_base_pose: np.ndarray,
        ee_in_arm_base_pose: np.ndarray,
        camera_K: np.ndarray,
    ) -> np.ndarray:
        assert target_in_camera.shape == (3,), "target_in_camera must be a vector of size 3"
        target_in_camera_homo = np.array([target_in_camera[0], target_in_camera[1], target_in_camera[2], 1.0], dtype=float)
        TARTER_IN_ARM_BASE = (camera_in_arm_base_pose @ target_in_camera_homo)
        CAMERA_IN_EE = np.linalg.inv(ee_in_arm_base_pose) @ camera_in_arm_base_pose
        
        best_v_err = self.cal_v_err(target_in_camera, camera_K)
        best_tilt = None
        for tilt in self.TILT_RANGE:
            arm_angles_deg_new = arm_angles_deg.copy()
            arm_angles_deg_new[4] = float(tilt)
            ee_in_arm_base_pose_new = self.manip_fk(
                np.deg2rad(arm_angles_deg_new), return_mm=False, return_pose=True
            )
            camera_in_arm_base_pose_new = ee_in_arm_base_pose_new @ CAMERA_IN_EE
            target_in_camera_new = (np.linalg.inv(camera_in_arm_base_pose_new) @ TARTER_IN_ARM_BASE)[:3]
            v_err_new = self.cal_v_err(target_in_camera_new, camera_K)
            # print(tilt, v_err_new)
            if v_err_new < best_v_err:
                best_v_err = v_err_new
                best_tilt = float(tilt)
        if best_tilt is not None:
            arm_angles_deg_new[4] = best_tilt
        else:
            arm_angles_deg_new = arm_angles_deg

        return arm_angles_deg_new


    def compute_look_at_target_pan(
        self,
        arm_angles_deg: np.ndarray,
        target_in_camera: np.ndarray,
        camera_in_arm_base_pose: np.ndarray,
        ee_in_arm_base_pose: np.ndarray,
        camera_K: np.ndarray,
    ) -> np.ndarray:
        assert target_in_camera.shape == (3,), "target_in_camera must be a vector of size 3"
        target_in_camera_homo = np.array([target_in_camera[0], target_in_camera[1], target_in_camera[2], 1.0], dtype=float)
        TARTER_IN_ARM_BASE = (camera_in_arm_base_pose @ target_in_camera_homo)
        CAMERA_IN_EE = np.linalg.inv(ee_in_arm_base_pose) @ camera_in_arm_base_pose

        best_u_err = self.cal_u_err(target_in_camera, camera_K)
        best_pan = None
        for pan in self.PAN_RANGE:
            arm_angles_deg_new = arm_angles_deg.copy()
            arm_angles_deg_new[0] = float(pan)
            ee_in_arm_base_pose_new = self.manip_fk(
                np.deg2rad(arm_angles_deg_new), return_mm=False, return_pose=True
            )
            camera_in_arm_base_pose_new = ee_in_arm_base_pose_new @ CAMERA_IN_EE
            target_in_camera_new = (np.linalg.inv(camera_in_arm_base_pose_new) @ TARTER_IN_ARM_BASE)[:3]
            u_err_new = self.cal_u_err(target_in_camera_new, camera_K)
            # print(pan, u_err_new)
            if u_err_new < best_u_err:
                best_u_err = u_err_new
                best_pan = float(pan)
        if best_pan is not None:
            arm_angles_deg_new[0] = best_pan
        else:
            arm_angles_deg_new = arm_angles_deg

        return arm_angles_deg_new



    # def compute_look_at_target_tilt(
    #     self,
    #     arm_angles_deg: np.ndarray,
    #     target_in_map_point: np.ndarray,
    #     camera_in_map_pose: np.ndarray,
    #     arm_base_in_map_pose: np.ndarray,
    #     camera_in_arm_base_pose: np.ndarray,
    #     ee_in_arm_base_pose: np.ndarray,
    #     camera_K: np.ndarray,
    # ) -> np.ndarray:
    #     target_in_map = np.array([target_in_map_point[0], target_in_map_point[1], target_in_map_point[2], 1.0], dtype=float)
    #     target_in_camera = (np.linalg.inv(camera_in_map_pose) @ target_in_map)[:3]
    #     TARTER_IN_ARM_BASE = (np.linalg.inv(arm_base_in_map_pose) @ target_in_map)
    #     CAMERA_IN_EE = np.linalg.inv(ee_in_arm_base_pose) @ camera_in_arm_base_pose

    #     best_v_err = self.cal_v_err(target_in_camera, camera_K)
    #     best_tilt = None
    #     arm_angles_deg_new = arm_angles_deg.copy()
    #     for tilt in self.TILT_RANGE:
    #         arm_angles_deg_new = arm_angles_deg.copy()
    #         arm_angles_deg_new[4] = float(tilt)
    #         ee_in_arm_base_pose_new = self.manip_fk(
    #             np.deg2rad(arm_angles_deg_new), return_mm=False, return_pose=True
    #         )
    #         camera_in_arm_base_pose_new = ee_in_arm_base_pose_new @ CAMERA_IN_EE
    #         target_in_camera_new = (np.linalg.inv(camera_in_arm_base_pose_new) @ TARTER_IN_ARM_BASE)[:3]
    #         v_err_new = self.cal_v_err(target_in_camera_new, camera_K)
    #         # print(tilt, v_err_new)
    #         if v_err_new < best_v_err:
    #             best_v_err = v_err_new
    #             best_tilt = float(tilt)
    #     if best_tilt is not None:
    #         arm_angles_deg_new[4] = best_tilt
    #     else:
    #         arm_angles_deg_new = arm_angles_deg

    #     return arm_angles_deg_new


    # def compute_look_at_target_pan(
    #     self,
    #     arm_angles_deg: np.ndarray,
    #     target_in_map_point: np.ndarray,
    #     camera_in_map_pose: np.ndarray,
    #     arm_base_in_map_pose: np.ndarray,
    #     camera_in_arm_base_pose: np.ndarray,
    #     ee_in_arm_base_pose: np.ndarray,
    #     camera_K: np.ndarray,
    # ) -> np.ndarray:
    #     target_in_map = np.array([target_in_map_point[0], target_in_map_point[1], target_in_map_point[2], 1.0], dtype=float)
    #     target_in_camera = (np.linalg.inv(camera_in_map_pose) @ target_in_map)[:3]
    #     TARTER_IN_ARM_BASE = (np.linalg.inv(arm_base_in_map_pose) @ target_in_map)
    #     CAMERA_IN_EE = np.linalg.inv(ee_in_arm_base_pose) @ camera_in_arm_base_pose

    #     best_u_err = self.cal_u_err(target_in_camera, camera_K)
    #     best_pan = None
    #     arm_angles_deg_new = arm_angles_deg.copy()
    #     for pan in self.PAN_RANGE:
    #         arm_angles_deg_new = arm_angles_deg.copy()
    #         arm_angles_deg_new[0] = float(pan)
    #         ee_in_arm_base_pose_new = self.manip_fk(
    #             np.deg2rad(arm_angles_deg_new), return_mm=False, return_pose=True
    #         )
    #         camera_in_arm_base_pose_new = ee_in_arm_base_pose_new @ CAMERA_IN_EE
    #         target_in_camera_new = (np.linalg.inv(camera_in_arm_base_pose_new) @ TARTER_IN_ARM_BASE)[:3]
    #         u_err_new = self.cal_u_err(target_in_camera_new, camera_K)
    #         # print(pan, u_err_new)
    #         if u_err_new < best_u_err:
    #             best_u_err = u_err_new
    #             best_pan = float(pan)
    #     if best_pan is not None:
    #         arm_angles_deg_new[0] = best_pan
    #     else:
    #         arm_angles_deg_new = arm_angles_deg

    #     return arm_angles_deg_new


    def compute_look_at_target_tilt_angle(
        self,
        arm_angles_deg: np.ndarray,
        target_in_map_point: np.ndarray,
        arm_base_in_map_pose: np.ndarray,
        camera_in_arm_base_pose: np.ndarray,
        ee_in_arm_base_pose: np.ndarray,
    ) -> np.ndarray:

        target_in_map_homo = np.array([target_in_map_point[0], target_in_map_point[1], target_in_map_point[2], 1.0], dtype=float)
        target_in_arm_base = (np.linalg.inv(arm_base_in_map_pose) @ target_in_map_homo)[:3]
        CAMERA_IN_EE = np.linalg.inv(ee_in_arm_base_pose) @ camera_in_arm_base_pose

        # R_cam_in_arm_base_cur = camera_in_arm_base_pose[:3, :3]
        # p_cam_in_arm_base_cur = camera_in_arm_base_pose[:3, 3]

        # distance_arm_base_cur = target_in_arm_base - p_cam_in_arm_base_cur
        # dist_cur = float(np.linalg.norm(distance_arm_base_cur))

        # dir_cam_z = distance_arm_base_cur / dist_cur
        # dir_cam_cur = R_cam_in_arm_base_cur.T @ (dir_cam_z)

        # tilt_err = np.arctan2(dir_cam_cur[1], dir_cam_cur[2])

        tilt_err = self.cal_tilt_err(camera_in_arm_base_pose, target_in_arm_base)
        if self.check_tilt_err(tilt_err):
            return arm_angles_deg

        min_tilt_err = tilt_err
        best_tilt = None
        arm_angles_deg_new = arm_angles_deg.copy()
        for tilt in self.TILT_RANGE:
            arm_angles_deg_new[4] = float(tilt)
            ee_in_arm_base_pose_new = self.manip_fk(np.deg2rad(arm_angles_deg_new))
            camera_in_arm_base_pose_new = ee_in_arm_base_pose_new @ CAMERA_IN_EE
            
            tilt_err_new = self.cal_tilt_err(camera_in_arm_base_pose_new, target_in_arm_base)
            print(tilt, tilt_err_new)
            if tilt_err_new < min_tilt_err:
                min_tilt_err = tilt_err_new
                best_tilt = tilt
                if self.check_tilt_err(tilt_err_new):
                    arm_angles_deg_new[4] = best_tilt
                    return arm_angles_deg_new
        
        if best_tilt is not None:
            print(f"compute_look_at_target_tilt best_tilt: {best_tilt}")
            arm_angles_deg_new[4] = best_tilt
        return arm_angles_deg_new



    # def compute_look_at_target_tilt_ik(
    #     self,
    #     arm_angles_deg: np.ndarray,
    #     target_in_map_point: np.ndarray,
    #     arm_base_in_map_pose: np.ndarray,
    #     camera_in_arm_base_pose: np.ndarray,
    #     ee_in_arm_base_pose: np.ndarray,
    # ) -> np.ndarray:

    #     target_in_map_homo = np.array([target_in_map_point[0], target_in_map_point[1], target_in_map_point[2], 1.0], dtype=float)
    #     target_in_arm_base = (np.linalg.inv(arm_base_in_map_pose) @ target_in_map_homo)[:3]
    #     camera_in_ee = np.linalg.inv(ee_in_arm_base_pose) @ camera_in_arm_base_pose

    #     R_cam_in_arm_base_cur = camera_in_arm_base_pose[:3, :3]
    #     p_cam_in_arm_base_cur = camera_in_arm_base_pose[:3, 3]

    #     # Symmetric z-search: 0, -step, +step, -2*step, +2*step, ... (meters)
    #     import time
    #     t0 = time.time()
    #     max_steps = 100
    #     step_m = 0.03
    #     for attempt in range(max_steps + 1):
    #         p_try = p_cam_in_arm_base_cur.copy()
    #         if attempt == 0:
    #             dz = 0.0
    #         else:
    #             k = (attempt + 1) // 2
    #             sign = -1.0 if (attempt % 2 == 1) else 1.0
    #             dz = sign * k * step_m
    #         p_try[2] = p_cam_in_arm_base_cur[2] + dz

    #         distance_arm_base_cur = target_in_arm_base - p_try
    #         dist_cur = float(np.linalg.norm(distance_arm_base_cur))

    #         dir_cam_z = distance_arm_base_cur / dist_cur
    #         dir_cam_cur = R_cam_in_arm_base_cur.T @ (dir_cam_z)

    #         tilt_err = np.arctan2(dir_cam_cur[1], dir_cam_cur[2])

    #         c, s = np.cos(-tilt_err), np.sin(-tilt_err)
    #         Rx = np.array([[1.0, 0.0, 0.0],
    #                     [0.0,   c,  -s],
    #                     [0.0,   s,   c]], dtype=float)
    #         R_cam_in_base_new = R_cam_in_arm_base_cur @ Rx

    #         camera_in_arm_base_pose_new = np.eye(4, dtype=float)
    #         camera_in_arm_base_pose_new[:3, :3] = R_cam_in_base_new
    #         camera_in_arm_base_pose_new[:3, 3] = p_try

    #         ee_in_arm_base_pose_new = camera_in_arm_base_pose_new @ np.linalg.inv(camera_in_ee)

    #         q_init = np.deg2rad(arm_angles_deg)
    #         success, arm_angles_deg_new, _ = self.manip_ik(
    #             ee_in_arm_base_pose_new,
    #             q_init=q_init,
    #             return_degrees=True,
    #             verbose=False
    #         )
    #         if success:
    #             break
    #     t1 = time.time()
    #     print(f"compute_look_at_target_tilt time: {t1 - t0}")

    #     if success:
    #         print(f"compute_look_at_target_tilt success: {arm_angles_deg_new}, attempt: {attempt}")
    #         return arm_angles_deg_new
    #     print(f"compute_look_at_target_tilt failed: {arm_angles_deg_new}")
    #     return arm_angles_deg

    def visualize_frames(
        self,
        poses: List[Tuple[np.ndarray, str]],
        axis_len: float = 0.1,
        title: Optional[str] = None,
        point: Optional[np.ndarray] = None,
        save: Optional[str] = None,
    ) -> None:
        import matplotlib.pyplot as plt
        from mpl_toolkits.mplot3d import Axes3D  # noqa: F401

        fig = plt.figure(figsize=(7, 7))
        ax = fig.add_subplot(111, projection="3d")

        I = np.eye(4)
        self._draw_frame(ax, I, "base", axis_len=axis_len, alpha=0.25, linewidth=1.0)

        for T, label in poses:
            self._draw_frame(ax, T, label, axis_len=axis_len, alpha=1.0, linewidth=2.0)

        if point is not None:
            p = np.asarray(point, dtype=float).reshape(3)
            ax.scatter([p[0]], [p[1]], [p[2]], c="k", s=40, label="target")

        ax.set_xlabel("X (m)")
        ax.set_ylabel("Y (m)")
        ax.set_zlabel("Z (m)")
        if title:
            ax.set_title(title)

        # bounds
        all_pts = [T[:3, 3] for T, _ in poses]
        if point is not None:
            all_pts.append(np.asarray(point, dtype=float).reshape(3))
        if all_pts:
            all_pts = np.array(all_pts)
            mins = all_pts.min(axis=0)
            maxs = all_pts.max(axis=0)
            pad = max(1e-3, 0.1 * float(np.linalg.norm(maxs - mins)))
            ax.set_xlim(mins[0] - pad, maxs[0] + pad)
            ax.set_ylim(mins[1] - pad, maxs[1] + pad)
            ax.set_zlim(mins[2] - pad, maxs[2] + pad)
        self._set_axes_equal(ax)

        if point is not None:
            ax.legend(loc="upper left")

        if save:
            import os
            os.makedirs(os.path.dirname(save), exist_ok=True)
            plt.savefig(save, bbox_inches="tight", dpi=150)
        plt.show()

    def visualize_camera_poses(
        self,
        camera_in_base_pose: np.ndarray,
        camera_in_base_pose_new: np.ndarray,
        target_point: Optional[np.ndarray] = None,
        axis_len: float = 0.1,
        title: Optional[str] = "Camera frames in base",
        save: Optional[str] = None,
    ) -> None:
        import matplotlib.pyplot as plt
        from mpl_toolkits.mplot3d import Axes3D  # noqa: F401

        fig = plt.figure(figsize=(7, 7))
        ax = fig.add_subplot(111, projection="3d")

        I = np.eye(4)
        self._draw_frame(ax, I, "base", axis_len=axis_len, alpha=0.25, linewidth=1.0)

        T_cur = np.asarray(camera_in_base_pose, dtype=float)
        T_new = np.asarray(camera_in_base_pose_new, dtype=float)

        # 当前相机细线，新相机加粗
        self._draw_frame(ax, T_cur, "cur", axis_len=axis_len, alpha=0.9, linewidth=2.0)
        self._draw_frame(ax, T_new, "new", axis_len=axis_len, alpha=1.0, linewidth=4.0)

        if target_point is not None:
            p = np.asarray(target_point, dtype=float).reshape(3)
            ax.scatter([p[0]], [p[1]], [p[2]], c="k", s=40, label="target")

        ax.set_xlabel("X (m)")
        ax.set_ylabel("Y (m)")
        ax.set_zlabel("Z (m)")
        if title:
            ax.set_title(title)

        # bounds
        all_pts = [T_cur[:3, 3], T_new[:3, 3]]
        if target_point is not None:
            all_pts.append(np.asarray(target_point, dtype=float).reshape(3))
        all_pts = np.array(all_pts)
        mins = all_pts.min(axis=0)
        maxs = all_pts.max(axis=0)
        pad = max(1e-3, 0.1 * float(np.linalg.norm(maxs - mins)))
        ax.set_xlim(mins[0] - pad, maxs[0] + pad)
        ax.set_ylim(mins[1] - pad, maxs[1] + pad)
        ax.set_zlim(mins[2] - pad, maxs[2] + pad)
        self._set_axes_equal(ax)

        if target_point is not None:
            ax.legend(loc="upper left")

        if save:
            import os
            os.makedirs(os.path.dirname(save), exist_ok=True)
            plt.savefig(save, bbox_inches="tight", dpi=150)
        plt.show()

    @staticmethod
    def _draw_frame(ax, T: np.ndarray, label: str, axis_len: float, alpha: float = 1.0, linewidth: float = 2.0) -> None:
        Rm = T[:3, :3]
        p = T[:3, 3]
        x_axis = Rm[:, 0] * axis_len
        y_axis = Rm[:, 1] * axis_len
        z_axis = Rm[:, 2] * axis_len
        ax.plot([p[0], p[0] + x_axis[0]], [p[1], p[1] + x_axis[1]], [p[2], p[2] + x_axis[2]], color="r", alpha=alpha, linewidth=linewidth)
        ax.plot([p[0], p[0] + y_axis[0]], [p[1], p[1] + y_axis[1]], [p[2], p[2] + y_axis[2]], color="g", alpha=alpha, linewidth=linewidth)
        ax.plot([p[0], p[0] + z_axis[0]], [p[1], p[1] + z_axis[1]], [p[2], p[2] + z_axis[2]], color="b", alpha=alpha, linewidth=linewidth)
        ax.text(p[0], p[1], p[2], f" {label}", color="k")

    @staticmethod
    def _set_axes_equal(ax) -> None:
        x_limits = ax.get_xlim3d()
        y_limits = ax.get_ylim3d()
        z_limits = ax.get_zlim3d()
        x_range = abs(x_limits[1] - x_limits[0])
        y_range = abs(y_limits[1] - y_limits[0])
        z_range = abs(z_limits[1] - z_limits[0])
        max_range = max([x_range, y_range, z_range])
        x_middle = float(np.mean(x_limits))
        y_middle = float(np.mean(y_limits))
        z_middle = float(np.mean(z_limits))
        ax.set_xlim3d([x_middle - max_range / 2, x_middle + max_range / 2])
        ax.set_ylim3d([y_middle - max_range / 2, y_middle + max_range / 2])
        ax.set_zlim3d([z_middle - max_range / 2, z_middle + max_range / 2])

if __name__ == "__main__":
    from scipy.spatial.transform import Rotation as R
    
    print("=" * 60)
    print("RangerxARM Kinematics Test")
    print("=" * 60)
    
    kinematics = RangerxARMKinematics(verbose=True)
    
    # Test 1: Forward Kinematics
    print("\n[Test 1] Forward Kinematics")
    print("-" * 60)
    joints_deg = [0, -45, -90, 0, 110, 0]
    joints_rad = np.deg2rad(joints_deg)
    
    position_m, rotation = kinematics.manip_fk(joints_rad, return_mm=False, return_pose=False)
    position_mm, _ = kinematics.manip_fk(joints_rad, return_mm=True)
    roll, pitch, yaw = np.rad2deg(R.from_matrix(rotation).as_euler('xyz'))
    
    print(f"Input joints (deg): {joints_deg}")
    print(f"Position (m): [{position_m[0]:.4f}, {position_m[1]:.4f}, {position_m[2]:.4f}]")
    print(f"Position (mm): [{position_mm[0]:.1f}, {position_mm[1]:.1f}, {position_mm[2]:.1f}]")
    print(f"Orientation (deg): roll={roll:.1f}, pitch={pitch:.1f}, yaw={yaw:.1f}")
    
    # Test 2: Inverse Kinematics (using pose_from_xyzrpy helper)
    print("\n[Test 2] Inverse Kinematics")
    print("-" * 60)
    target_x, target_y, target_z = 204.3, -8.9, 590.2  # mm
    target_roll, target_pitch, target_yaw = 177.8, -25, 0  # deg
    
    target_pose = RangerxARMKinematics.pose_from_xyzrpy(
        target_x, target_y, target_z,
        target_roll, target_pitch, target_yaw,
        degrees=True,
        input_mm=True
    )
    
    print(f"Target position (mm): [{target_x}, {target_y}, {target_z}]")
    print(f"Target orientation (deg): roll={target_roll}, pitch={target_pitch}, yaw={target_yaw}")
    
    success, joints_solution, debug_info = kinematics.manip_ik(target_pose, verbose=False)
    
    if success:
        print(f"✓ IK converged in {debug_info['iterations']} iterations")
        print(f"  Final error norm: {debug_info['final_error_norm']:.6f}")
        print(f"  Solution (deg): {np.round(joints_solution, 2).tolist()}")
        
        # Verify with FK
        pos_verify, rot_verify = kinematics.manip_fk(np.deg2rad(joints_solution), return_mm=True)
        print(f"  FK verification (mm): [{pos_verify[0]:.1f}, {pos_verify[1]:.1f}, {pos_verify[2]:.1f}]")
    else:
        print(f"✗ IK failed after {debug_info['iterations']} iterations")
        print(f"  Final error norm: {debug_info['final_error_norm']:.6f}")
